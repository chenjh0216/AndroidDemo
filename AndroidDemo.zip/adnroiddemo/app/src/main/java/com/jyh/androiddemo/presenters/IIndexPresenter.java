package com.jyh.androiddemo.presenters;

public interface IIndexPresenter extends IBasePresenter {
}
