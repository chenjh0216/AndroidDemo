package com.jyh.androiddemo.presenters.impl;

import com.jyh.androiddemo.presenters.IBasePresenter;

public class DefaultPresenter implements IBasePresenter {

    @Override
    public void onCreate() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onRestart() {

    }

    @Override
    public void onDestroy() {

    }
}
