package com.jyh.androiddemo.dao.daoimpl;

import com.jyh.androiddemo.dao.IGoodsAccess;

public class GoodsAccessImpl implements IGoodsAccess {
}
