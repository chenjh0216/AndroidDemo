package com.jyh.androiddemo.dao;

public interface IGoodsAccess {
}
